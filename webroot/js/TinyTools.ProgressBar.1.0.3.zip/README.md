ProgressBar
===========

ProgressBar is a tiny and simple jQuery plugin that displays status of a determinate or indeterminate process.

It is a visual element to show the progress of an activity. The default theme of the progress bar is gradient; but you can change it on your own.

See the [project page] [ProgressBar Site] for documentation and demonstration.


[ProgressBar Site]:http://tinytools.codesells.com/progressbar